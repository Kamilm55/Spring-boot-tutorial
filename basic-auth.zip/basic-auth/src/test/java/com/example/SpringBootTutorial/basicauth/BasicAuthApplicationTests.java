package com.example.SpringBootTutorial.basicauth;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BasicAuthApplicationTests {

	@Test
	void contextLoads() {
	}

}
